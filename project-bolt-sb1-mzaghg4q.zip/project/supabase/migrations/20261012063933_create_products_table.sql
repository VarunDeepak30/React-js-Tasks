/*
# Create products table for GOUDS STORE e-commerce

1. New Tables
- `products`
  - `id` (uuid, primary key)
  - `title` (text, product name)
  - `price` (numeric, product price)
  - `description` (text, product description)
  - `category` (text, product category)
  - `image` (text, URL to product image)
  - `rating_rate` (numeric, rating value 0-5)
  - `rating_count` (integer, number of ratings)
  - `created_at` (timestamp)

2. Security
- Enable RLS on `products`.
- Allow anon + authenticated CRUD — this is a single-tenant e-commerce demo with no sign-in.
- All data is intentionally public/shared.

3. Indexes
- Index on `category` for fast filtering.
*/

CREATE TABLE IF NOT EXISTS products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  price numeric(10,2) NOT NULL DEFAULT 0,
  description text NOT NULL DEFAULT '',
  category text NOT NULL DEFAULT 'uncategorized',
  image text NOT NULL DEFAULT '',
  rating_rate numeric(3,2) NOT NULL DEFAULT 0,
  rating_count integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE products ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_select_products" ON products;
CREATE POLICY "anon_select_products" ON products FOR SELECT
  TO anon, authenticated USING (true);

DROP POLICY IF EXISTS "anon_insert_products" ON products;
CREATE POLICY "anon_insert_products" ON products FOR INSERT
  TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "anon_update_products" ON products;
CREATE POLICY "anon_update_products" ON products FOR UPDATE
  TO anon, authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "anon_delete_products" ON products;
CREATE POLICY "anon_delete_products" ON products FOR DELETE
  TO anon, authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_products_category ON products(category);
