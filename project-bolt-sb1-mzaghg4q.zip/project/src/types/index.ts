export interface Product {
  id: string;
  title: string;
  price: number;
  description: string;
  category: string;
  image: string;
  rating_rate: number;
  rating_count: number;
}

export interface CartItem {
  product: Product;
  quantity: number;
}

export interface ProductFormData {
  title: string;
  price: string;
  description: string;
  category: string;
  image: string;
  rating_rate: string;
  rating_count: string;
}
