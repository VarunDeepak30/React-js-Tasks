import { Outlet, NavLink } from 'react-router-dom';
import { Wrench, Truck, RefreshCw, Shield, Headphones, CreditCard } from 'lucide-react';
import Breadcrumbs from '@/components/Breadcrumbs';

const services = [
  { icon: Wrench, title: 'Product Repair', desc: 'Professional repair services for all your electronics and gadgets.' },
  { icon: Truck, title: 'Fast Delivery', desc: 'Quick and reliable delivery to your doorstep, wherever you are.' },
  { icon: RefreshCw, title: 'Easy Returns', desc: 'Not satisfied? Return any product within 30 days for a full refund.' },
  { icon: Shield, title: 'Extended Warranty', desc: 'Protect your purchases with our comprehensive warranty plans.' },
  { icon: Headphones, title: '24/7 Support', desc: 'Our customer support team is always ready to help you.' },
  { icon: CreditCard, title: 'Flexible Payment', desc: 'Multiple payment options including installments and financing.' },
];

const subNavLinks = [
  { to: '/services', label: 'Overview', end: true },
  { to: '/services/delivery', label: 'Delivery', end: false },
  { to: '/services/returns', label: 'Returns', end: false },
];

export default function Services() {
  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Services' }]} />

      <div className="mt-4">
        <h1 className="text-3xl font-extrabold text-gray-900">Our Services</h1>
        <p className="mt-2 text-sm text-gray-500">
          Everything you need for a seamless shopping experience
        </p>
      </div>

      {/* Sub-navigation for nested routes */}
      <nav className="mt-6 flex gap-2 border-b border-gray-100">
        {subNavLinks.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            end={link.end}
            className={({ isActive }) =>
              `border-b-2 px-4 py-2.5 text-sm font-semibold transition-colors ${
                isActive
                  ? 'border-orange-500 text-orange-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700'
              }`
            }
          >
            {link.label}
          </NavLink>
        ))}
      </nav>

      {/* Nested route content */}
      <div className="mt-8">
        <Outlet />
      </div>

      {/* Services grid — always visible on the overview */}
      <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {services.map((service) => (
          <div
            key={service.title}
            className="group rounded-2xl border border-gray-100 bg-white p-6 shadow-sm transition-all hover:-translate-y-1 hover:shadow-xl"
          >
            <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-orange-100 transition-colors group-hover:bg-orange-500">
              <service.icon
                size={22}
                className="text-orange-600 transition-colors group-hover:text-white"
              />
            </div>
            <h3 className="mt-4 font-bold text-gray-800">{service.title}</h3>
            <p className="mt-2 text-sm leading-relaxed text-gray-500">{service.desc}</p>
          </div>
        ))}
      </div>
    </div>
  );
}
