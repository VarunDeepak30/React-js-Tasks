import { RefreshCw, CheckCircle, AlertCircle } from 'lucide-react';

export default function Returns() {
  const steps = [
    'Contact our support team within 30 days of delivery.',
    'Provide your order number and reason for return.',
    'Pack the item securely in its original packaging.',
    'We arrange a pickup or provide a return label.',
    'Once received and inspected, your refund is processed within 5-7 business days.',
  ];

  return (
    <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm lg:p-8">
      <h2 className="text-2xl font-extrabold text-gray-900">Returns Policy</h2>
      <p className="mt-2 text-gray-600">
        We want you to love every purchase. If something isn't right, we're here to help.
      </p>

      {/* Returns steps */}
      <div className="mt-8">
        <h3 className="font-bold text-gray-800">How to Return an Item</h3>
        <div className="mt-4 space-y-3">
          {steps.map((step, idx) => (
            <div key={idx} className="flex items-start gap-3">
              <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-orange-500 text-sm font-bold text-white">
                {idx + 1}
              </div>
              <p className="pt-0.5 text-sm text-gray-600">{step}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Do's and Don'ts */}
      <div className="mt-8 grid gap-4 sm:grid-cols-2">
        <div className="rounded-xl border border-green-100 bg-green-50 p-5">
          <CheckCircle className="text-green-500" size={24} />
          <h4 className="mt-3 font-bold text-gray-800">Returnable Items</h4>
          <ul className="mt-2 space-y-1 text-sm text-gray-600">
            <li>Items in original condition and packaging</li>
            <li>Unwashed and unworn clothing</li>
            <li>Electronics with all accessories included</li>
            <li>Items within the 30-day return window</li>
          </ul>
        </div>
        <div className="rounded-xl border border-red-100 bg-red-50 p-5">
          <AlertCircle className="text-red-500" size={24} />
          <h4 className="mt-3 font-bold text-gray-800">Non-Returnable Items</h4>
          <ul className="mt-2 space-y-1 text-sm text-gray-600">
            <li>Items damaged after delivery</li>
            <li>Personalized or custom products</li>
            <li>Gift cards and final sale items</li>
            <li>Items returned after 30 days</li>
          </ul>
        </div>
      </div>

      <div className="mt-8 flex items-center gap-3 rounded-xl bg-orange-50 p-5">
        <RefreshCw className="shrink-0 text-orange-500" size={24} />
        <p className="text-sm text-gray-600">
          <span className="font-bold text-gray-800">Need to make a return?</span> Visit our
          Contact page and our support team will guide you through the process.
        </p>
      </div>
    </div>
  );
}
