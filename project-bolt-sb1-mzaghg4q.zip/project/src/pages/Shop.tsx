import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { SlidersHorizontal, X } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { loadProducts, loadCategories } from '@/store/productsSlice';
import ProductCard from '@/components/ProductCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorState from '@/components/ErrorState';
import EmptyState from '@/components/EmptyState';
import { useDebounce } from '@/hooks/useDebounce';
import Breadcrumbs from '@/components/Breadcrumbs';

type SortOption = 'default' | 'price-low' | 'price-high' | 'rating' | 'name';

export default function Shop() {
  const dispatch = useAppDispatch();
  const { products, categories, loading, error } = useAppSelector((state) => state.products);
  const [searchParams, setSearchParams] = useSearchParams();

  const urlQuery = searchParams.get('q') ?? '';
  const urlCategory = searchParams.get('category') ?? 'all';
  const urlSort = (searchParams.get('sort') ?? 'default') as SortOption;

  const [localQuery, setLocalQuery] = useState(urlQuery);
  const [showFilters, setShowFilters] = useState(false);
  const debouncedQuery = useDebounce(localQuery, 300);

  useEffect(() => {
    dispatch(loadProducts());
    dispatch(loadCategories());
  }, [dispatch]);

  useEffect(() => {
    setLocalQuery(urlQuery);
  }, [urlQuery]);

  const filteredProducts = useMemo(() => {
    let result = [...products];

    if (urlCategory !== 'all') {
      result = result.filter((p) => p.category === urlCategory);
    }

    if (debouncedQuery) {
      const q = debouncedQuery.toLowerCase();
      result = result.filter(
        (p) =>
          p.title.toLowerCase().includes(q) ||
          p.description.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q)
      );
    }

    switch (urlSort) {
      case 'price-low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result.sort((a, b) => b.rating_rate - a.rating_rate);
        break;
      case 'name':
        result.sort((a, b) => a.title.localeCompare(b.title));
        break;
    }

    return result;
  }, [products, urlCategory, debouncedQuery, urlSort]);

  const updateParam = (key: string, value: string) => {
    const next = new URLSearchParams(searchParams);
    if (value && value !== 'all' && value !== 'default') {
      next.set(key, value);
    } else {
      next.delete(key);
    }
    setSearchParams(next);
  };

  if (loading && products.length === 0) return <LoadingSpinner message="Loading products..." />;
  if (error) return <ErrorState message={error} />;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Shop' }]} />

      <div className="mt-4 flex items-end justify-between">
        <div>
          <h1 className="text-3xl font-extrabold text-gray-900">Shop All Products</h1>
          <p className="mt-1 text-sm text-gray-500">
            {filteredProducts.length} product{filteredProducts.length !== 1 ? 's' : ''} found
          </p>
        </div>
        <button
          onClick={() => setShowFilters(!showFilters)}
          className="flex items-center gap-2 rounded-lg border border-gray-200 px-4 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-gray-50 lg:hidden"
        >
          {showFilters ? <X size={16} /> : <SlidersHorizontal size={16} />}
          Filters
        </button>
      </div>

      <div className="mt-6 flex flex-col gap-6 lg:flex-row">
        {/* Sidebar Filters */}
        <aside
          className={`${showFilters ? 'block' : 'hidden'} w-full shrink-0 lg:block lg:w-64`}
        >
          <div className="sticky top-20 space-y-6 rounded-2xl border border-gray-100 bg-white p-5 shadow-sm">
            {/* Search filter */}
            <div>
              <label className="text-sm font-bold text-gray-800">Search</label>
              <input
                type="text"
                value={localQuery}
                onChange={(e) => setLocalQuery(e.target.value)}
                onBlur={() => updateParam('q', localQuery)}
                onKeyDown={(e) => e.key === 'Enter' && updateParam('q', localQuery)}
                placeholder="Search products..."
                className="mt-2 w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-orange-400 focus:outline-none focus:ring-2 focus:ring-orange-100"
              />
            </div>

            {/* Category filter */}
            <div>
              <label className="text-sm font-bold text-gray-800">Category</label>
              <div className="mt-2 space-y-1">
                <button
                  onClick={() => updateParam('category', 'all')}
                  className={`block w-full rounded-lg px-3 py-2 text-left text-sm font-medium transition-colors ${
                    urlCategory === 'all'
                      ? 'bg-orange-500 text-white'
                      : 'text-gray-600 hover:bg-orange-50'
                  }`}
                >
                  All Categories
                </button>
                {categories.map((cat) => (
                  <button
                    key={cat}
                    onClick={() => updateParam('category', cat)}
                    className={`block w-full rounded-lg px-3 py-2 text-left text-sm font-medium capitalize transition-colors ${
                      urlCategory === cat
                        ? 'bg-orange-500 text-white'
                        : 'text-gray-600 hover:bg-orange-50'
                    }`}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            {/* Sort filter */}
            <div>
              <label className="text-sm font-bold text-gray-800">Sort By</label>
              <select
                value={urlSort}
                onChange={(e) => updateParam('sort', e.target.value)}
                className="mt-2 w-full rounded-lg border border-gray-200 px-3 py-2 text-sm focus:border-orange-400 focus:outline-none focus:ring-2 focus:ring-orange-100"
              >
                <option value="default">Default</option>
                <option value="price-low">Price: Low to High</option>
                <option value="price-high">Price: High to Low</option>
                <option value="rating">Top Rated</option>
                <option value="name">Name: A to Z</option>
              </select>
            </div>

            {(urlCategory !== 'all' || urlQuery || urlSort !== 'default') && (
              <button
                onClick={() => {
                  setSearchParams(new URLSearchParams());
                  setLocalQuery('');
                }}
                className="w-full rounded-lg border border-gray-200 py-2 text-sm font-medium text-gray-600 transition-colors hover:bg-gray-50"
              >
                Clear All Filters
              </button>
            )}
          </div>
        </aside>

        {/* Products grid */}
        <div className="flex-1">
          {filteredProducts.length === 0 ? (
            <EmptyState message="No products match your search. Try adjusting your filters." />
          ) : (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-3 xl:grid-cols-4">
              {filteredProducts.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
