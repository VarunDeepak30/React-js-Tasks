import { useEffect, useMemo } from 'react';
import { Link } from 'react-router-dom';
import { ArrowRight, Truck, ShieldCheck, Headphones, RefreshCw, Sparkles, TrendingUp } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { loadProducts, loadCategories } from '@/store/productsSlice';
import ProductCard from '@/components/ProductCard';
import CategoryCard from '@/components/CategoryCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorState from '@/components/ErrorState';
import { useSearch } from '@/context/SearchContext';

export default function Home() {
  const dispatch = useAppDispatch();
  const { products, categories, loading, error } = useAppSelector((state) => state.products);
  const { setSearchQuery } = useSearch();

  useEffect(() => {
    dispatch(loadProducts());
    dispatch(loadCategories());
  }, [dispatch]);

  const featuredProducts = useMemo(() => {
    return [...products]
      .sort((a, b) => b.rating_rate - a.rating_rate)
      .slice(0, 8);
  }, [products]);

  const newProducts = useMemo(() => {
    return [...products].slice(-4);
  }, [products]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    products.forEach((p) => {
      counts[p.category] = (counts[p.category] ?? 0) + 1;
    });
    return counts;
  }, [products]);

  if (loading && products.length === 0) return <LoadingSpinner message="Loading products..." />;
  if (error) return <ErrorState message={error} />;

  return (
    <div>
      {/* Hero Banner */}
      <section className="relative overflow-hidden bg-gradient-to-br from-orange-500 via-orange-500 to-amber-500">
        <div className="absolute inset-0 opacity-10">
          <div className="absolute -right-20 top-10 h-72 w-72 rounded-full bg-white" />
          <div className="absolute -left-10 bottom-0 h-48 w-48 rounded-full bg-white" />
        </div>
        <div className="relative mx-auto max-w-7xl px-4 py-16 sm:px-6 lg:px-8 lg:py-24">
          <div className="grid items-center gap-8 lg:grid-cols-2">
            <div className="text-center lg:text-left">
              <span className="inline-flex items-center gap-2 rounded-full bg-white/20 px-4 py-1.5 text-sm font-semibold text-white backdrop-blur">
                <Sparkles size={16} /> Welcome to GOUDS STORE
              </span>
              <h1 className="mt-4 text-4xl font-extrabold leading-tight text-white sm:text-5xl lg:text-6xl">
                Shop Smart, <br /> Live Better
              </h1>
              <p className="mt-4 max-w-lg text-lg text-orange-50 lg:mx-0 mx-auto">
                Discover amazing deals on electronics, clothing, jewelry, and more.
                Quality products at prices you'll love, delivered right to your door.
              </p>
              <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center lg:justify-start">
                <Link
                  to="/shop"
                  onClick={() => setSearchQuery('')}
                  className="group inline-flex items-center justify-center gap-2 rounded-full bg-white px-8 py-3.5 text-base font-bold text-orange-600 shadow-lg transition-all hover:shadow-xl hover:scale-105"
                >
                  Shop Now
                  <ArrowRight size={20} className="transition-transform group-hover:translate-x-1" />
                </Link>
                <Link
                  to="/categories"
                  className="inline-flex items-center justify-center gap-2 rounded-full border-2 border-white/40 px-8 py-3.5 text-base font-bold text-white backdrop-blur transition-all hover:bg-white/10"
                >
                  Browse Categories
                </Link>
              </div>
            </div>
            <div className="hidden lg:block">
              <div className="relative rounded-3xl bg-white/10 p-8 backdrop-blur">
                <div className="grid grid-cols-2 gap-4">
                  {featuredProducts.slice(0, 4).map((product) => (
                    <Link
                      key={product.id}
                      to={`/product/${product.id}`}
                      className="group flex flex-col items-center rounded-2xl bg-white p-4 shadow-lg transition-transform hover:scale-105"
                    >
                      <img
                        src={product.image}
                        alt={product.title}
                        loading="lazy"
                        className="h-24 w-24 object-contain"
                      />
                      <span className="mt-2 text-sm font-bold text-gray-900">
                        ${product.price.toFixed(2)}
                      </span>
                    </Link>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Feature bar */}
      <section className="border-b border-gray-100 bg-white">
        <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {[
              { icon: Truck, title: 'Free Shipping', desc: 'On orders over $50' },
              { icon: RefreshCw, title: 'Easy Returns', desc: '30-day return policy' },
              { icon: ShieldCheck, title: 'Secure Payment', desc: 'Protected checkout' },
              { icon: Headphones, title: '24/7 Support', desc: 'Always here to help' },
            ].map((feature) => (
              <div
                key={feature.title}
                className="flex items-center gap-3 rounded-xl p-3 transition-colors hover:bg-orange-50"
              >
                <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-orange-100">
                  <feature.icon size={20} className="text-orange-600" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-gray-800">{feature.title}</h3>
                  <p className="text-xs text-gray-500">{feature.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Categories */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h2 className="text-2xl font-extrabold text-gray-900">Shop by Category</h2>
            <p className="mt-1 text-sm text-gray-500">Find exactly what you're looking for</p>
          </div>
          <Link
            to="/categories"
            className="flex items-center gap-1 text-sm font-semibold text-orange-600 hover:gap-2 transition-all"
          >
            View All <ArrowRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {categories.map((cat) => (
            <CategoryCard
              key={cat}
              category={cat}
              count={categoryCounts[cat] ?? 0}
              image=""
            />
          ))}
        </div>
      </section>

      {/* Featured products */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="mb-6 flex items-end justify-between">
          <div>
            <h2 className="flex items-center gap-2 text-2xl font-extrabold text-gray-900">
              <TrendingUp size={24} className="text-orange-500" /> Top Rated Products
            </h2>
            <p className="mt-1 text-sm text-gray-500">Our highest-rated products by customers</p>
          </div>
          <Link
            to="/shop"
            onClick={() => setSearchQuery('')}
            className="flex items-center gap-1 text-sm font-semibold text-orange-600 hover:gap-2 transition-all"
          >
            View All <ArrowRight size={16} />
          </Link>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {featuredProducts.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* New arrivals */}
      <section className="bg-orange-50/50">
        <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
          <div className="mb-6">
            <h2 className="text-2xl font-extrabold text-gray-900">New Arrivals</h2>
            <p className="mt-1 text-sm text-gray-500">Fresh products just added to our catalog</p>
          </div>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {newProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-gray-900 to-gray-800 px-8 py-12 text-center">
          <div className="absolute -right-16 -top-16 h-48 w-48 rounded-full bg-orange-500/20" />
          <div className="absolute -bottom-12 -left-12 h-40 w-40 rounded-full bg-orange-500/10" />
          <div className="relative">
            <h2 className="text-3xl font-extrabold text-white">Ready to Start Shopping?</h2>
            <p className="mt-3 text-gray-400">
              Browse our full catalog and find the best deals today.
            </p>
            <Link
              to="/shop"
              onClick={() => setSearchQuery('')}
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-orange-500 px-8 py-3.5 text-base font-bold text-white shadow-lg transition-all hover:bg-orange-600 hover:scale-105"
            >
              Explore Shop <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
