import { useEffect, useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { ShoppingCart, ArrowLeft, Check, Minus, Plus, Truck, ShieldCheck, RefreshCw } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { loadProductById, loadProducts, clearSelectedProduct } from '@/store/productsSlice';
import { addToCart } from '@/store/cartSlice';
import RatingStars from '@/components/RatingStars';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorState from '@/components/ErrorState';
import Breadcrumbs from '@/components/Breadcrumbs';
import ProductCard from '@/components/ProductCard';

export default function ProductDetails() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const dispatch = useAppDispatch();
  const { selectedProduct, products, loading, error } = useAppSelector((state) => state.products);
  const [quantity, setQuantity] = useState(1);
  const [added, setAdded] = useState(false);

  useEffect(() => {
    if (id) {
      dispatch(loadProductById(id));
      dispatch(loadProducts());
    }
    return () => {
      dispatch(clearSelectedProduct());
    };
  }, [dispatch, id]);

  const relatedProducts = products
    .filter(
      (p) =>
        p.category === selectedProduct?.category && p.id !== selectedProduct?.id
    )
    .slice(0, 4);

  if (loading && !selectedProduct) return <LoadingSpinner message="Loading product..." />;
  if (error) return <ErrorState message={error} />;
  if (!selectedProduct)
    return (
      <div className="mx-auto max-w-7xl px-4 py-16 text-center">
        <h2 className="text-2xl font-bold text-gray-700">Product not found</h2>
        <Link to="/shop" className="mt-4 inline-block text-orange-600 hover:underline">
          Back to Shop
        </Link>
      </div>
    );

  const handleAddToCart = () => {
    dispatch(addToCart(selectedProduct));
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <Breadcrumbs
        items={[
          { label: 'Home', to: '/' },
          { label: 'Shop', to: '/shop' },
          { label: selectedProduct.title },
        ]}
      />

      <button
        onClick={() => navigate(-1)}
        className="mt-4 flex items-center gap-2 text-sm font-medium text-gray-500 transition-colors hover:text-orange-600"
      >
        <ArrowLeft size={16} /> Back
      </button>

      {/* Product detail */}
      <div className="mt-6 grid gap-8 lg:grid-cols-2">
        {/* Image */}
        <div className="relative flex items-center justify-center rounded-2xl border border-gray-100 bg-gray-50 p-8">
          <span className="absolute left-4 top-4 rounded-full bg-orange-500 px-3 py-1 text-xs font-bold uppercase text-white">
            {selectedProduct.category}
          </span>
          <img
            src={selectedProduct.image}
            alt={selectedProduct.title}
            className="max-h-96 w-full object-contain"
          />
        </div>

        {/* Info */}
        <div className="flex flex-col">
          <h1 className="text-2xl font-extrabold leading-tight text-gray-900">
            {selectedProduct.title}
          </h1>
          <div className="mt-3">
            <RatingStars
              rate={selectedProduct.rating_rate}
              count={selectedProduct.rating_count}
              size={18}
            />
          </div>
          <p className="mt-4 text-3xl font-extrabold text-orange-600">
            ${selectedProduct.price.toFixed(2)}
          </p>
          <p className="mt-4 leading-relaxed text-gray-600">
            {selectedProduct.description}
          </p>

          {/* Quantity selector */}
          <div className="mt-6 flex items-center gap-4">
            <span className="text-sm font-bold text-gray-800">Quantity:</span>
            <div className="flex items-center rounded-lg border border-gray-200">
              <button
                onClick={() => setQuantity(Math.max(1, quantity - 1))}
                className="flex h-10 w-10 items-center justify-center text-gray-600 transition-colors hover:bg-gray-50"
                aria-label="Decrease quantity"
              >
                <Minus size={16} />
              </button>
              <span className="w-12 text-center font-semibold text-gray-900">{quantity}</span>
              <button
                onClick={() => setQuantity(quantity + 1)}
                className="flex h-10 w-10 items-center justify-center text-gray-600 transition-colors hover:bg-gray-50"
                aria-label="Increase quantity"
              >
                <Plus size={16} />
              </button>
            </div>
          </div>

          {/* Add to cart */}
          <button
            onClick={handleAddToCart}
            className={`mt-6 flex items-center justify-center gap-2 rounded-xl px-8 py-3.5 text-base font-bold text-white shadow-lg transition-all hover:scale-105 ${
              added ? 'bg-green-500' : 'bg-orange-500 hover:bg-orange-600'
            }`}
          >
            {added ? (
              <>
                <Check size={20} /> Added to Cart!
              </>
            ) : (
              <>
                <ShoppingCart size={20} /> Add to Cart
              </>
            )}
          </button>

          {/* Trust badges */}
          <div className="mt-8 grid grid-cols-3 gap-3">
            {[
              { icon: Truck, label: 'Free Shipping', sub: 'Over $50' },
              { icon: ShieldCheck, label: 'Secure', sub: 'Payment' },
              { icon: RefreshCw, label: '30-Day', sub: 'Returns' },
            ].map((badge) => (
              <div
                key={badge.label}
                className="flex flex-col items-center gap-1 rounded-xl border border-gray-100 bg-gray-50 p-3 text-center"
              >
                <badge.icon size={20} className="text-orange-500" />
                <span className="text-xs font-bold text-gray-700">{badge.label}</span>
                <span className="text-xs text-gray-400">{badge.sub}</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Related products */}
      {relatedProducts.length > 0 && (
        <section className="mt-16">
          <h2 className="text-2xl font-extrabold text-gray-900">Related Products</h2>
          <div className="mt-6 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {relatedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
