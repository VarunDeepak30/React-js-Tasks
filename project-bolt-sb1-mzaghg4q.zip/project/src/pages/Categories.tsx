import { useEffect, useMemo } from 'react';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import { loadProducts, loadCategories } from '@/store/productsSlice';
import CategoryCard from '@/components/CategoryCard';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorState from '@/components/ErrorState';
import Breadcrumbs from '@/components/Breadcrumbs';

export default function Categories() {
  const dispatch = useAppDispatch();
  const { products, categories, loading, error } = useAppSelector((state) => state.products);

  useEffect(() => {
    dispatch(loadProducts());
    dispatch(loadCategories());
  }, [dispatch]);

  const categoryCounts = useMemo(() => {
    const counts: Record<string, number> = {};
    products.forEach((p) => {
      counts[p.category] = (counts[p.category] ?? 0) + 1;
    });
    return counts;
  }, [products]);

  if (loading && products.length === 0) return <LoadingSpinner message="Loading categories..." />;
  if (error) return <ErrorState message={error} />;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Categories' }]} />

      <div className="mt-4 text-center">
        <h1 className="text-3xl font-extrabold text-gray-900">All Categories</h1>
        <p className="mt-2 text-sm text-gray-500">
          Browse our wide range of product categories
        </p>
      </div>

      <div className="mt-8 grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
        {categories.map((cat) => (
          <CategoryCard
            key={cat}
            category={cat}
            count={categoryCounts[cat] ?? 0}
            image=""
          />
        ))}
      </div>
    </div>
  );
}
