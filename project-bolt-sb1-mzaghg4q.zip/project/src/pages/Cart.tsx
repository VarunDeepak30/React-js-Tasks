import { Link } from 'react-router-dom';
import { Minus, Plus, Trash2, ShoppingBag, ArrowRight } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import {
  incrementQuantity,
  decrementQuantity,
  removeFromCart,
  clearCart,
} from '@/store/cartSlice';
import { useCart } from '@/hooks/useCart';
import Breadcrumbs from '@/components/Breadcrumbs';
import EmptyState from '@/components/EmptyState';

export default function Cart() {
  const dispatch = useAppDispatch();
  const { items, totalItems, subtotal, tax, shipping, total } = useCart();

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Cart' }]} />
        <div className="mt-8">
          <EmptyState message="Your cart is empty. Start shopping and add some products!" />
          <div className="mt-6 text-center">
            <Link
              to="/shop"
              className="inline-flex items-center gap-2 rounded-full bg-orange-500 px-8 py-3.5 text-base font-bold text-white shadow-lg transition-all hover:bg-orange-600 hover:scale-105"
            >
              <ShoppingBag size={20} /> Continue Shopping
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Cart' }]} />

      <div className="mt-4 flex items-center justify-between">
        <h1 className="text-3xl font-extrabold text-gray-900">
          Shopping Cart ({totalItems})
        </h1>
        <button
          onClick={() => dispatch(clearCart())}
          className="text-sm font-medium text-gray-500 transition-colors hover:text-red-500"
        >
          Clear Cart
        </button>
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-3">
        {/* Cart items */}
        <div className="lg:col-span-2 space-y-3">
          {items.map(({ product, quantity }) => (
            <div
              key={product.id}
              className="flex gap-4 rounded-2xl border border-gray-100 bg-white p-4 shadow-sm"
            >
              <Link
                to={`/product/${product.id}`}
                className="flex h-24 w-24 shrink-0 items-center justify-center rounded-xl bg-gray-50 p-2"
              >
                <img
                  src={product.image}
                  alt={product.title}
                  loading="lazy"
                  className="h-full w-full object-contain"
                />
              </Link>

              <div className="flex flex-1 flex-col">
                <div className="flex items-start justify-between gap-2">
                  <Link
                    to={`/product/${product.id}`}
                    className="line-clamp-2 text-sm font-semibold text-gray-800 transition-colors hover:text-orange-600"
                  >
                    {product.title}
                  </Link>
                  <button
                    onClick={() => dispatch(removeFromCart(product.id))}
                    className="shrink-0 rounded-lg p-1.5 text-gray-400 transition-colors hover:bg-red-50 hover:text-red-500"
                    aria-label="Remove from cart"
                  >
                    <Trash2 size={18} />
                  </button>
                </div>
                <span className="mt-1 text-xs text-gray-400">{product.category}</span>

                <div className="mt-auto flex items-center justify-between pt-2">
                  {/* Quantity controls */}
                  <div className="flex items-center rounded-lg border border-gray-200">
                    <button
                      onClick={() => dispatch(decrementQuantity(product.id))}
                      className="flex h-8 w-8 items-center justify-center text-gray-600 transition-colors hover:bg-gray-50"
                      aria-label="Decrease quantity"
                    >
                      <Minus size={14} />
                    </button>
                    <span className="w-10 text-center text-sm font-semibold text-gray-900">
                      {quantity}
                    </span>
                    <button
                      onClick={() => dispatch(incrementQuantity(product.id))}
                      className="flex h-8 w-8 items-center justify-center text-gray-600 transition-colors hover:bg-gray-50"
                      aria-label="Increase quantity"
                    >
                      <Plus size={14} />
                    </button>
                  </div>

                  <div className="text-right">
                    <span className="text-sm text-gray-400">
                      ${product.price.toFixed(2)} each
                    </span>
                    <p className="text-lg font-bold text-gray-900">
                      ${(product.price * quantity).toFixed(2)}
                    </p>
                  </div>
                </div>
              </div>
            </div>
          ))}

          <Link
            to="/shop"
            className="inline-flex items-center gap-1 text-sm font-semibold text-orange-600 hover:gap-2 transition-all"
          >
            Continue Shopping <ArrowRight size={16} />
          </Link>
        </div>

        {/* Order summary */}
        <div className="lg:col-span-1">
          <div className="sticky top-20 rounded-2xl border border-gray-100 bg-white p-6 shadow-sm">
            <h2 className="text-lg font-extrabold text-gray-900">Order Summary</h2>

            <div className="mt-4 space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-gray-500">Subtotal ({totalItems} items)</span>
                <span className="font-semibold text-gray-800">${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Tax (8%)</span>
                <span className="font-semibold text-gray-800">${tax.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-500">Shipping</span>
                <span className="font-semibold text-gray-800">
                  {shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}
                </span>
              </div>

              {shipping > 0 && (
                <p className="rounded-lg bg-orange-50 px-3 py-2 text-xs text-orange-600">
                  Add ${(50 - subtotal).toFixed(2)} more for free shipping!
                </p>
              )}

              <div className="border-t border-gray-100 pt-3">
                <div className="flex justify-between">
                  <span className="text-base font-bold text-gray-900">Total</span>
                  <span className="text-2xl font-extrabold text-orange-600">
                    ${total.toFixed(2)}
                  </span>
                </div>
              </div>
            </div>

            <button className="mt-6 flex w-full items-center justify-center gap-2 rounded-xl bg-orange-500 px-6 py-3.5 text-base font-bold text-white shadow-lg transition-all hover:bg-orange-600 hover:scale-105">
              Proceed to Checkout <ArrowRight size={20} />
            </button>

            <div className="mt-4 flex items-center justify-center gap-2 text-xs text-gray-400">
              <ShoppingBag size={14} /> Secure checkout powered by GOUDS STORE
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
