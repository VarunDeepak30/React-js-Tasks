import { Truck, Clock, MapPin, Package, CheckCircle } from 'lucide-react';

export default function Delivery() {
  const steps = [
    { icon: Package, title: 'Order Placed', desc: 'We confirm your order immediately.' },
    { icon: MapPin, title: 'Processing', desc: 'Your items are packed with care at our warehouse.' },
    { icon: Truck, title: 'Shipped', desc: 'Your package is on its way to your location.' },
    { icon: CheckCircle, title: 'Delivered', desc: 'Your order arrives at your doorstep.' },
  ];

  return (
    <div className="rounded-2xl border border-gray-100 bg-white p-6 shadow-sm lg:p-8">
      <h2 className="text-2xl font-extrabold text-gray-900">Delivery Information</h2>
      <p className="mt-2 text-gray-600">
        We offer fast, reliable shipping to ensure your products arrive safely and on time.
      </p>

      {/* Delivery steps */}
      <div className="mt-8 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
        {steps.map((step, idx) => (
          <div key={step.title} className="relative">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-orange-100">
              <step.icon size={24} className="text-orange-600" />
            </div>
            <span className="absolute right-0 top-0 text-3xl font-extrabold text-orange-100">
              {idx + 1}
            </span>
            <h3 className="mt-3 font-bold text-gray-800">{step.title}</h3>
            <p className="mt-1 text-sm text-gray-500">{step.desc}</p>
          </div>
        ))}
      </div>

      {/* Info cards */}
      <div className="mt-8 grid gap-4 sm:grid-cols-3">
        <div className="rounded-xl border border-gray-100 bg-gray-50 p-5">
          <Clock className="text-orange-500" size={24} />
          <h4 className="mt-3 font-bold text-gray-800">Delivery Times</h4>
          <p className="mt-1 text-sm text-gray-500">
            Standard: 3-5 business days. Express: 1-2 business days.
          </p>
        </div>
        <div className="rounded-xl border border-gray-100 bg-gray-50 p-5">
          <Truck className="text-orange-500" size={24} />
          <h4 className="mt-3 font-bold text-gray-800">Shipping Costs</h4>
          <p className="mt-1 text-sm text-gray-500">
            Free shipping on orders over $50. Flat $5.99 for orders below.
          </p>
        </div>
        <div className="rounded-xl border border-gray-100 bg-gray-50 p-5">
          <MapPin className="text-orange-500" size={24} />
          <h4 className="mt-3 font-bold text-gray-800">Coverage</h4>
          <p className="mt-1 text-sm text-gray-500">
            We deliver nationwide. International shipping available for select regions.
          </p>
        </div>
      </div>
    </div>
  );
}
