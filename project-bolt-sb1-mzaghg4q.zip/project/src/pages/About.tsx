import { Link } from 'react-router-dom';
import { Target, Eye, Heart, Award, Users, ShoppingBag, ArrowRight } from 'lucide-react';
import Breadcrumbs from '@/components/Breadcrumbs';

export default function About() {
  const stats = [
    { icon: Users, label: 'Happy Customers', value: '50K+' },
    { icon: ShoppingBag, label: 'Products Sold', value: '120K+' },
    { icon: Award, label: 'Awards Won', value: '15+' },
    { icon: Heart, label: 'Years in Business', value: '10+' },
  ];

  const values = [
    {
      icon: Target,
      title: 'Our Mission',
      desc: 'To provide high-quality products at affordable prices, making online shopping accessible and enjoyable for everyone.',
    },
    {
      icon: Eye,
      title: 'Our Vision',
      desc: 'To become the most trusted and loved e-commerce platform, known for exceptional service and customer satisfaction.',
    },
    {
      icon: Heart,
      title: 'Our Values',
      desc: 'Integrity, quality, and customer-first thinking guide everything we do. We treat every customer like family.',
    },
  ];

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-to-br from-orange-500 to-amber-500 py-16">
        <div className="mx-auto max-w-7xl px-4 text-center sm:px-6 lg:px-8">
          <h1 className="text-4xl font-extrabold text-white sm:text-5xl">About GOUDS STORE</h1>
          <p className="mx-auto mt-4 max-w-2xl text-lg text-orange-50">
            We're more than just an online store. We're your trusted partner for quality products
            and exceptional shopping experiences.
          </p>
        </div>
      </section>

      <div className="mx-auto max-w-7xl px-4 py-12 sm:px-6 lg:px-8">
        <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'About' }]} />

        {/* Stats */}
        <div className="mt-8 grid grid-cols-2 gap-4 lg:grid-cols-4">
          {stats.map((stat) => (
            <div
              key={stat.label}
              className="flex flex-col items-center gap-2 rounded-2xl border border-gray-100 bg-white p-6 text-center shadow-sm transition-all hover:shadow-lg"
            >
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-orange-100">
                <stat.icon size={24} className="text-orange-600" />
              </div>
              <span className="text-2xl font-extrabold text-gray-900">{stat.value}</span>
              <span className="text-sm text-gray-500">{stat.label}</span>
            </div>
          ))}
        </div>

        {/* Story */}
        <section className="mt-16 grid items-center gap-8 lg:grid-cols-2">
          <div>
            <h2 className="text-3xl font-extrabold text-gray-900">Our Story</h2>
            <p className="mt-4 leading-relaxed text-gray-600">
              Founded in 2015, GOUDS STORE started as a small online shop with a big dream: to make
              quality products accessible to everyone. What began as a passion project has grown into
              a trusted e-commerce platform serving thousands of customers worldwide.
            </p>
            <p className="mt-4 leading-relaxed text-gray-600">
              We carefully curate our product selection, partnering with top brands and suppliers to
              bring you the best in electronics, fashion, jewelry, and more. Every product we sell is
              backed by our commitment to quality and customer satisfaction.
            </p>
            <Link
              to="/shop"
              className="mt-6 inline-flex items-center gap-2 rounded-full bg-orange-500 px-6 py-3 text-sm font-bold text-white transition-all hover:bg-orange-600 hover:gap-3"
            >
              Start Shopping <ArrowRight size={18} />
            </Link>
          </div>
          <div className="grid gap-4">
            {values.map((value) => (
              <div
                key={value.title}
                className="flex gap-4 rounded-2xl border border-gray-100 bg-white p-5 shadow-sm"
              >
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-orange-100">
                  <value.icon size={22} className="text-orange-600" />
                </div>
                <div>
                  <h3 className="font-bold text-gray-800">{value.title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-gray-500">{value.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Team CTA */}
        <section className="mt-16 rounded-3xl bg-orange-50 p-8 text-center lg:p-12">
          <h2 className="text-3xl font-extrabold text-gray-900">Join Our Family</h2>
          <p className="mx-auto mt-3 max-w-xl text-gray-600">
            Become part of our growing community. Shop with confidence and experience the GOUDS
            STORE difference.
          </p>
          <Link
            to="/contact"
            className="mt-6 inline-flex items-center gap-2 rounded-full bg-orange-500 px-8 py-3.5 text-base font-bold text-white shadow-lg transition-all hover:bg-orange-600 hover:scale-105"
          >
            Get in Touch <ArrowRight size={20} />
          </Link>
        </section>
      </div>
    </div>
  );
}
