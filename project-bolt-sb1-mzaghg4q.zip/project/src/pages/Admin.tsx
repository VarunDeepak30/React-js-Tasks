import { useEffect, useState } from 'react';
import { Plus, Pencil, Trash2, X, Save, Package } from 'lucide-react';
import { useAppDispatch, useAppSelector } from '@/store/hooks';
import {
  loadProducts,
  setProducts,
  addProduct,
  editProduct,
  removeProduct,
} from '@/store/productsSlice';
import {
  createProduct,
  updateProduct,
  deleteProduct,
} from '@/services/productService';
import type { Product, ProductFormData } from '@/types';
import LoadingSpinner from '@/components/LoadingSpinner';
import ErrorState from '@/components/ErrorState';
import Breadcrumbs from '@/components/Breadcrumbs';

const emptyForm: ProductFormData = {
  title: '',
  price: '',
  description: '',
  category: '',
  image: '',
  rating_rate: '',
  rating_count: '',
};

export default function Admin() {
  const dispatch = useAppDispatch();
  const { products, loading, error } = useAppSelector((state) => state.products);

  const [showModal, setShowModal] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<ProductFormData>(emptyForm);
  const [formErrors, setFormErrors] = useState<Partial<Record<keyof ProductFormData, string>>>({});
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [confirmDelete, setConfirmDelete] = useState<string | null>(null);

  useEffect(() => {
    dispatch(loadProducts());
  }, [dispatch]);

  const validate = (): boolean => {
    const errors: Partial<Record<keyof ProductFormData, string>> = {};

    if (!form.title.trim()) errors.title = 'Title is required';
    else if (form.title.trim().length < 3) errors.title = 'Title must be at least 3 characters';

    if (!form.price) errors.price = 'Price is required';
    else if (isNaN(Number(form.price)) || Number(form.price) < 0)
      errors.price = 'Price must be a positive number';

    if (!form.description.trim()) errors.description = 'Description is required';
    else if (form.description.trim().length < 10)
      errors.description = 'Description must be at least 10 characters';

    if (!form.category.trim()) errors.category = 'Category is required';

    if (!form.image.trim()) errors.image = 'Image URL is required';
    else if (!/^https?:\/\//.test(form.image)) errors.image = 'Must be a valid URL';

    if (!form.rating_rate) errors.rating_rate = 'Rating is required';
    else if (isNaN(Number(form.rating_rate)) || Number(form.rating_rate) < 0 || Number(form.rating_rate) > 5)
      errors.rating_rate = 'Rating must be between 0 and 5';

    if (!form.rating_count) errors.rating_count = 'Count is required';
    else if (isNaN(Number(form.rating_count)) || Number(form.rating_count) < 0)
      errors.rating_count = 'Count must be a positive number';

    setFormErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const openAddModal = () => {
    setForm(emptyForm);
    setEditingId(null);
    setFormErrors({});
    setSubmitError(null);
    setShowModal(true);
  };

  const openEditModal = (product: Product) => {
    setForm({
      title: product.title,
      price: String(product.price),
      description: product.description,
      category: product.category,
      image: product.image,
      rating_rate: String(product.rating_rate),
      rating_count: String(product.rating_count),
    });
    setEditingId(product.id);
    setFormErrors({});
    setSubmitError(null);
    setShowModal(true);
  };

  const closeModal = () => {
    setShowModal(false);
    setForm(emptyForm);
    setFormErrors({});
    setSubmitError(null);
    setEditingId(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!validate()) return;

    setSubmitError(null);
    try {
      const payload = {
        title: form.title.trim(),
        price: Number(form.price),
        description: form.description.trim(),
        category: form.category.trim(),
        image: form.image.trim(),
        rating_rate: Number(form.rating_rate),
        rating_count: Number(form.rating_count),
      };

      if (editingId) {
        const updated = await updateProduct(editingId, payload);
        dispatch(editProduct(updated));
      } else {
        const created = await createProduct(payload);
        dispatch(addProduct(created));
      }
      closeModal();
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Failed to save product');
    }
  };

  const handleDelete = async (id: string) => {
    try {
      await deleteProduct(id);
      dispatch(removeProduct(id));
      setConfirmDelete(null);
    } catch (err) {
      setSubmitError(err instanceof Error ? err.message : 'Failed to delete product');
    }
  };

  if (loading && products.length === 0) return <LoadingSpinner message="Loading products..." />;
  if (error) return <ErrorState message={error} />;

  const inputClass = (field: keyof ProductFormData) =>
    `w-full rounded-lg border px-3 py-2 text-sm transition-colors focus:outline-none focus:ring-2 ${
      formErrors[field]
        ? 'border-red-300 focus:border-red-400 focus:ring-red-100'
        : 'border-gray-200 focus:border-orange-400 focus:ring-orange-100'
    }`;

  return (
    <div className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
      <Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Admin' }]} />

      <div className="mt-4 flex items-end justify-between">
        <div>
          <h1 className="flex items-center gap-2 text-3xl font-extrabold text-gray-900">
            <Package size={28} className="text-orange-500" /> Product Management
          </h1>
          <p className="mt-1 text-sm text-gray-500">
            {products.length} product{products.length !== 1 ? 's' : ''} in catalog
          </p>
        </div>
        <button
          onClick={openAddModal}
          className="flex items-center gap-2 rounded-xl bg-orange-500 px-5 py-2.5 text-sm font-bold text-white shadow-lg transition-all hover:bg-orange-600 hover:scale-105"
        >
          <Plus size={18} /> Add Product
        </button>
      </div>

      {/* Products table — desktop */}
      <div className="mt-6 hidden overflow-hidden rounded-2xl border border-gray-100 bg-white shadow-sm lg:block">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-gray-100 bg-gray-50">
            <tr>
              <th className="px-4 py-3 font-bold text-gray-700">Product</th>
              <th className="px-4 py-3 font-bold text-gray-700">Category</th>
              <th className="px-4 py-3 font-bold text-gray-700">Price</th>
              <th className="px-4 py-3 font-bold text-gray-700">Rating</th>
              <th className="px-4 py-3 text-right font-bold text-gray-700">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-50">
            {products.map((product) => (
              <tr key={product.id} className="transition-colors hover:bg-orange-50/30">
                <td className="px-4 py-3">
                  <div className="flex items-center gap-3">
                    <img
                      src={product.image}
                      alt={product.title}
                      loading="lazy"
                      className="h-12 w-12 rounded-lg bg-gray-50 object-contain p-1"
                    />
                    <span className="line-clamp-1 max-w-xs font-medium text-gray-800">
                      {product.title}
                    </span>
                  </div>
                </td>
                <td className="px-4 py-3 capitalize text-gray-600">{product.category}</td>
                <td className="px-4 py-3 font-semibold text-gray-800">
                  ${product.price.toFixed(2)}
                </td>
                <td className="px-4 py-3 text-gray-600">
                  {product.rating_rate.toFixed(1)} ({product.rating_count})
                </td>
                <td className="px-4 py-3">
                  <div className="flex items-center justify-end gap-2">
                    <button
                      onClick={() => openEditModal(product)}
                      className="flex items-center gap-1.5 rounded-lg border border-gray-200 px-3 py-1.5 text-xs font-semibold text-gray-600 transition-colors hover:bg-orange-50 hover:text-orange-600"
                    >
                      <Pencil size={14} /> Edit
                    </button>
                    <button
                      onClick={() => setConfirmDelete(product.id)}
                      className="flex items-center gap-1.5 rounded-lg border border-gray-200 px-3 py-1.5 text-xs font-semibold text-gray-600 transition-colors hover:bg-red-50 hover:text-red-500"
                    >
                      <Trash2 size={14} /> Delete
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Products cards — mobile */}
      <div className="mt-6 space-y-3 lg:hidden">
        {products.map((product) => (
          <div
            key={product.id}
            className="flex gap-3 rounded-2xl border border-gray-100 bg-white p-4 shadow-sm"
          >
            <img
              src={product.image}
              alt={product.title}
              loading="lazy"
              className="h-16 w-16 shrink-0 rounded-lg bg-gray-50 object-contain p-1"
            />
            <div className="flex-1">
              <h3 className="line-clamp-2 text-sm font-semibold text-gray-800">
                {product.title}
              </h3>
              <p className="mt-1 text-xs capitalize text-gray-400">{product.category}</p>
              <div className="mt-2 flex items-center justify-between">
                <span className="font-bold text-gray-900">${product.price.toFixed(2)}</span>
                <div className="flex gap-2">
                  <button
                    onClick={() => openEditModal(product)}
                    className="rounded-lg border border-gray-200 p-2 text-gray-600 transition-colors hover:bg-orange-50 hover:text-orange-600"
                  >
                    <Pencil size={14} />
                  </button>
                  <button
                    onClick={() => setConfirmDelete(product.id)}
                    className="rounded-lg border border-gray-200 p-2 text-gray-600 transition-colors hover:bg-red-50 hover:text-red-500"
                  >
                    <Trash2 size={14} />
                  </button>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Add/Edit modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-start justify-center overflow-y-auto bg-black/40 p-4 pt-10">
          <div className="w-full max-w-2xl rounded-2xl bg-white p-6 shadow-2xl lg:p-8">
            <div className="flex items-center justify-between">
              <h2 className="text-xl font-extrabold text-gray-900">
                {editingId ? 'Edit Product' : 'Add New Product'}
              </h2>
              <button
                onClick={closeModal}
                className="rounded-lg p-2 text-gray-400 transition-colors hover:bg-gray-100"
              >
                <X size={20} />
              </button>
            </div>

            {submitError && (
              <div className="mt-4 rounded-lg border border-red-200 bg-red-50 p-3 text-sm text-red-600">
                {submitError}
              </div>
            )}

            <form onSubmit={handleSubmit} className="mt-4 space-y-4" noValidate>
              <div>
                <label className="text-sm font-semibold text-gray-700">Title</label>
                <input
                  type="text"
                  name="title"
                  value={form.title}
                  onChange={handleChange}
                  placeholder="Product title"
                  className={`mt-1.5 ${inputClass('title')}`}
                />
                {formErrors.title && (
                  <p className="mt-1 text-xs text-red-500">{formErrors.title}</p>
                )}
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="text-sm font-semibold text-gray-700">Price ($)</label>
                  <input
                    type="text"
                    name="price"
                    value={form.price}
                    onChange={handleChange}
                    placeholder="0.00"
                    className={`mt-1.5 ${inputClass('price')}`}
                  />
                  {formErrors.price && (
                    <p className="mt-1 text-xs text-red-500">{formErrors.price}</p>
                  )}
                </div>
                <div>
                  <label className="text-sm font-semibold text-gray-700">Category</label>
                  <input
                    type="text"
                    name="category"
                    value={form.category}
                    onChange={handleChange}
                    placeholder="e.g. electronics"
                    className={`mt-1.5 ${inputClass('category')}`}
                  />
                  {formErrors.category && (
                    <p className="mt-1 text-xs text-red-500">{formErrors.category}</p>
                  )}
                </div>
              </div>

              <div>
                <label className="text-sm font-semibold text-gray-700">Description</label>
                <textarea
                  name="description"
                  value={form.description}
                  onChange={handleChange}
                  rows={3}
                  placeholder="Product description"
                  className={`mt-1.5 ${inputClass('description')}`}
                />
                {formErrors.description && (
                  <p className="mt-1 text-xs text-red-500">{formErrors.description}</p>
                )}
              </div>

              <div>
                <label className="text-sm font-semibold text-gray-700">Image URL</label>
                <input
                  type="text"
                  name="image"
                  value={form.image}
                  onChange={handleChange}
                  placeholder="https://example.com/image.png"
                  className={`mt-1.5 ${inputClass('image')}`}
                />
                {formErrors.image && (
                  <p className="mt-1 text-xs text-red-500">{formErrors.image}</p>
                )}
              </div>

              <div className="grid gap-4 sm:grid-cols-2">
                <div>
                  <label className="text-sm font-semibold text-gray-700">Rating (0-5)</label>
                  <input
                    type="text"
                    name="rating_rate"
                    value={form.rating_rate}
                    onChange={handleChange}
                    placeholder="4.5"
                    className={`mt-1.5 ${inputClass('rating_rate')}`}
                  />
                  {formErrors.rating_rate && (
                    <p className="mt-1 text-xs text-red-500">{formErrors.rating_rate}</p>
                  )}
                </div>
                <div>
                  <label className="text-sm font-semibold text-gray-700">Rating Count</label>
                  <input
                    type="text"
                    name="rating_count"
                    value={form.rating_count}
                    onChange={handleChange}
                    placeholder="120"
                    className={`mt-1.5 ${inputClass('rating_count')}`}
                  />
                  {formErrors.rating_count && (
                    <p className="mt-1 text-xs text-red-500">{formErrors.rating_count}</p>
                  )}
                </div>
              </div>

              <div className="flex gap-3 pt-2">
                <button
                  type="submit"
                  className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-orange-500 px-6 py-3 text-sm font-bold text-white shadow-lg transition-all hover:bg-orange-600"
                >
                  <Save size={18} /> {editingId ? 'Update Product' : 'Create Product'}
                </button>
                <button
                  type="button"
                  onClick={closeModal}
                  className="rounded-xl border border-gray-200 px-6 py-3 text-sm font-bold text-gray-600 transition-colors hover:bg-gray-50"
                >
                  Cancel
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Delete confirmation */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
          <div className="w-full max-w-sm rounded-2xl bg-white p-6 text-center shadow-2xl">
            <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-red-100">
              <Trash2 size={24} className="text-red-500" />
            </div>
            <h3 className="mt-4 text-lg font-bold text-gray-900">Delete Product?</h3>
            <p className="mt-2 text-sm text-gray-500">
              This action cannot be undone. The product will be permanently removed.
            </p>
            <div className="mt-6 flex gap-3">
              <button
                onClick={() => handleDelete(confirmDelete)}
                className="flex-1 rounded-xl bg-red-500 px-4 py-2.5 text-sm font-bold text-white transition-colors hover:bg-red-600"
              >
                Delete
              </button>
              <button
                onClick={() => setConfirmDelete(null)}
                className="flex-1 rounded-xl border border-gray-200 px-4 py-2.5 text-sm font-bold text-gray-600 transition-colors hover:bg-gray-50"
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
