import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Layout from '@/components/Layout';
import Home from '@/pages/Home';
import Shop from '@/pages/Shop';
import Categories from '@/pages/Categories';
import ProductDetails from '@/pages/ProductDetails';
import About from '@/pages/About';
import Services from '@/pages/Services';
import Delivery from '@/pages/Delivery';
import Returns from '@/pages/Returns';
import Contact from '@/pages/Contact';
import Cart from '@/pages/Cart';
import Admin from '@/pages/Admin';
import NotFound from '@/pages/NotFound';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Layout />}>
          <Route index element={<Home />} />
          <Route path="shop" element={<Shop />} />
          <Route path="categories" element={<Categories />} />
          <Route path="product/:id" element={<ProductDetails />} />
          <Route path="about" element={<About />} />
          <Route path="services" element={<Services />}>
            <Route index element={<Delivery />} />
            <Route path="delivery" element={<Delivery />} />
            <Route path="returns" element={<Returns />} />
          </Route>
          <Route path="contact" element={<Contact />} />
          <Route path="cart" element={<Cart />} />
          <Route path="admin" element={<Admin />} />
          <Route path="*" element={<NotFound />} />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}
