import { Star } from 'lucide-react';

interface RatingStarsProps {
  rate: number;
  count?: number;
  size?: number;
}

export default function RatingStars({ rate, count, size = 16 }: RatingStarsProps) {
  const fullStars = Math.floor(rate);
  const hasHalf = rate - fullStars >= 0.25;

  return (
    <div className="flex items-center gap-1">
      <div className="flex items-center">
        {Array.from({ length: 5 }).map((_, i) => {
          const isFull = i < fullStars;
          const isHalf = i === fullStars && hasHalf;
          return (
            <Star
              key={i}
              size={size}
              className={
                isFull
                  ? 'text-amber-400 fill-amber-400'
                  : isHalf
                    ? 'text-amber-400 fill-amber-400/50'
                    : 'text-gray-300'
              }
            />
          );
        })}
      </div>
      <span className="text-sm font-medium text-gray-600">{rate.toFixed(1)}</span>
      {count !== undefined && (
        <span className="text-sm text-gray-400">({count})</span>
      )}
    </div>
  );
}
