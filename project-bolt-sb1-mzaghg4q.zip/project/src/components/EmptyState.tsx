import { PackageSearch } from 'lucide-react';

export default function EmptyState({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-gray-100 bg-gray-50 py-16">
      <PackageSearch className="h-12 w-12 text-gray-300" />
      <h3 className="text-lg font-bold text-gray-600">Nothing found</h3>
      <p className="text-sm text-gray-400">{message}</p>
    </div>
  );
}
