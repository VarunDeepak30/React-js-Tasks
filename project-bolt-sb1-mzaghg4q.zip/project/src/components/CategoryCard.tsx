import { Star } from 'lucide-react';

interface CategoryCardProps {
  category: string;
  count: number;
  image: string;
}

const categoryIcons: Record<string, string> = {
  electronics: 'https://fakestoreapi.com/img/61IBBVJvSDL._AC_SY879_t.png',
  "men's clothing": 'https://fakestoreapi.com/img/71li-ujtlUL._AC_UX679_t.png',
  "women's clothing": 'https://fakestoreapi.com/img/51Y5NI-I5jL._AC_UX679_t.png',
  jewelery: 'https://fakestoreapi.com/img/71pWzhdJNwL._AC_UL640_QL65_ML3_t.png',
};

export default function CategoryCard({ category, count }: CategoryCardProps) {
  const image = categoryIcons[category] ?? categoryIcons['electronics'];

  return (
    <a
      href={`/shop?category=${encodeURIComponent(category)}`}
      className="group relative flex flex-col items-center gap-3 overflow-hidden rounded-2xl border border-gray-100 bg-white p-6 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
    >
      <div className="relative h-24 w-24 overflow-hidden rounded-full bg-orange-50 p-2">
        <img
          src={image}
          alt={category}
          loading="lazy"
          className="h-full w-full object-contain transition-transform duration-500 group-hover:scale-110"
        />
      </div>
      <div className="text-center">
        <h3 className="font-bold capitalize text-gray-800 transition-colors group-hover:text-orange-600">
          {category}
        </h3>
        <p className="mt-1 text-sm text-gray-500">{count} Products</p>
      </div>
      <div className="absolute right-3 top-3 flex items-center gap-1 rounded-full bg-amber-50 px-2 py-1 text-xs font-bold text-amber-600">
        <Star size={12} className="fill-amber-400 text-amber-400" />
      </div>
    </a>
  );
}
