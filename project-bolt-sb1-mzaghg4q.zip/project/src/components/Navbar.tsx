import { Link, useNavigate } from 'react-router-dom';
import { useState, useRef, useEffect } from 'react';
import { ShoppingBag, Search, Menu, X, ShoppingCart, ChevronDown } from 'lucide-react';
import { useAppSelector } from '@/store/hooks';
import { useSearch } from '@/context/SearchContext';

export default function Navbar() {
  const [mobileOpen, setMobileOpen] = useState(false);
  const [searchInput, setSearchInput] = useState('');
  const [scrolled, setScrolled] = useState(false);
  const navigate = useNavigate();
  const { setSearchQuery } = useSearch();
  const cartCount = useAppSelector((state) =>
    state.cart.items.reduce((sum, item) => sum + item.quantity, 0)
  );
  const searchRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 10);
    window.addEventListener('scroll', onScroll);
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchQuery(searchInput);
    navigate(`/shop?q=${encodeURIComponent(searchInput)}`);
    setMobileOpen(false);
  };

  const navLinks = [
    { to: '/', label: 'Home' },
    { to: '/shop', label: 'Shop' },
    { to: '/categories', label: 'Categories' },
    { to: '/about', label: 'About' },
    { to: '/services', label: 'Services' },
    { to: '/contact', label: 'Contact' },
    { to: '/admin', label: 'Admin' },
  ];

  return (
    <header
      className={`sticky top-0 z-50 transition-all duration-300 ${
        scrolled ? 'bg-white/95 shadow-lg backdrop-blur' : 'bg-white shadow-sm'
      }`}
    >
      <div className="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
        <div className="flex h-16 items-center justify-between gap-4">
          {/* Logo */}
          <Link to="/" className="flex shrink-0 items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-orange-400 to-orange-600 shadow-md">
              <ShoppingBag className="h-5 w-5 text-white" />
            </div>
            <div className="flex flex-col leading-none">
              <span className="text-lg font-extrabold tracking-tight text-gray-900">
                GOUDS
              </span>
              <span className="text-xs font-medium text-orange-500">STORE</span>
            </div>
          </Link>

          {/* Search bar — desktop */}
          <form
            onSubmit={handleSearch}
            className="hidden flex-1 max-w-xl items-center md:flex"
          >
            <div className="flex w-full items-center rounded-full border-2 border-orange-100 bg-orange-50/50 focus-within:border-orange-400 focus-within:bg-white transition-colors">
              <input
                ref={searchRef}
                type="text"
                value={searchInput}
                onChange={(e) => setSearchInput(e.target.value)}
                placeholder="Search for products..."
                className="w-full bg-transparent px-5 py-2.5 text-sm text-gray-700 placeholder-gray-400 focus:outline-none"
              />
              <button
                type="submit"
                className="flex h-10 w-12 items-center justify-center rounded-full bg-orange-500 text-white transition-colors hover:bg-orange-600"
                aria-label="Search"
              >
                <Search size={18} />
              </button>
            </div>
          </form>

          {/* Cart icon */}
          <Link
            to="/cart"
            className="relative flex shrink-0 items-center justify-center rounded-xl p-2 text-gray-700 transition-colors hover:bg-orange-50 hover:text-orange-600"
          >
            <ShoppingCart size={24} />
            {cartCount > 0 && (
              <span className="absolute -right-0.5 -top-0.5 flex h-5 min-w-5 items-center justify-center rounded-full bg-orange-500 px-1 text-xs font-bold text-white">
                {cartCount}
              </span>
            )}
          </Link>

          {/* Mobile menu toggle */}
          <button
            onClick={() => setMobileOpen(!mobileOpen)}
            className="flex shrink-0 items-center justify-center rounded-xl p-2 text-gray-700 transition-colors hover:bg-orange-50 md:hidden"
            aria-label="Menu"
          >
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>

          {/* Desktop nav links */}
          <nav className="hidden items-center gap-1 lg:flex">
            {navLinks.map((link) => (
              <Link
                key={link.to}
                to={link.to}
                className="rounded-lg px-3 py-2 text-sm font-medium text-gray-700 transition-colors hover:bg-orange-50 hover:text-orange-600"
              >
                {link.label}
              </Link>
            ))}
          </nav>
        </div>

        {/* Mobile menu */}
        {mobileOpen && (
          <div className="border-t border-gray-100 py-4 md:hidden">
            <form onSubmit={handleSearch} className="mb-4 flex items-center gap-2">
              <div className="flex flex-1 items-center rounded-full border-2 border-orange-100 bg-orange-50/50">
                <input
                  type="text"
                  value={searchInput}
                  onChange={(e) => setSearchInput(e.target.value)}
                  placeholder="Search..."
                  className="w-full bg-transparent px-4 py-2 text-sm focus:outline-none"
                />
                <button
                  type="submit"
                  className="flex h-9 w-10 items-center justify-center rounded-full bg-orange-500 text-white"
                  aria-label="Search"
                >
                  <Search size={16} />
                </button>
              </div>
            </form>
            <nav className="flex flex-col gap-1">
              {navLinks.map((link) => (
                <Link
                  key={link.to}
                  to={link.to}
                  onClick={() => setMobileOpen(false)}
                  className="flex items-center justify-between rounded-lg px-4 py-3 text-sm font-medium text-gray-700 transition-colors hover:bg-orange-50 hover:text-orange-600"
                >
                  {link.label}
                  <ChevronDown size={16} className="-rotate-90 text-gray-400" />
                </Link>
              ))}
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
