import { AlertCircle } from 'lucide-react';

export default function ErrorState({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-3 rounded-2xl border border-red-100 bg-red-50 py-16">
      <AlertCircle className="h-12 w-12 text-red-400" />
      <h3 className="text-lg font-bold text-red-700">Something went wrong</h3>
      <p className="max-w-md text-center text-sm text-red-500">{message}</p>
    </div>
  );
}
