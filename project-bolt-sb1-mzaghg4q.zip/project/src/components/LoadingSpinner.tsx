import { Loader2 } from 'lucide-react';

export default function LoadingSpinner({ message = 'Loading...' }: { message?: string }) {
  return (
    <div className="flex flex-col items-center justify-center gap-4 py-20">
      <Loader2 className="h-10 w-10 animate-spin text-orange-500" />
      <p className="text-sm font-medium text-gray-500">{message}</p>
    </div>
  );
}
